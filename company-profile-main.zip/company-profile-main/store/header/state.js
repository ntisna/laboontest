export default () => ({
  sidebarIsVisible: false,
  menuItems: ''
})
